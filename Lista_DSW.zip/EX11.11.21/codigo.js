        var tarefas = []
        var tarefas_concluidas = []
        
       

        
            
        function excluir_tarefas(valor_lista, id_li){
            
            var txt_li = tarefas[valor_lista]
            txt_li = txt_li[0]
            
           
            
            var id_check_exc = id_li.split("_")
            id_check_exc = id_check_exc[1]

            var id_tabela = `tabela_${id_check_exc}`
            id_check_exc = `check/${id_check_exc}`
            

            var check_exc = document.getElementById(id_check_exc)

           

            if (check_exc.checked){

                var pai_exc =  document.getElementById("tabela_con")

                

                var filho_exc = document.getElementById(id_tabela)


                pai_exc.removeChild(filho_exc)
            }


            var parent = document.getElementById(id_li).parentElement
    
            var child = document.getElementById(id_li);
    
            parent.removeChild(child);
    
            tarefas.splice(valor_lista, 1)

            var texto_excluido = document.createElement("td")
            texto_excluido.innerHTML = txt_li

            var data_excluida = document.createElement("td")
            var hoje = new Date()
            var mes = parseInt(hoje.getMonth())
            mes++
            var data =  (hoje.getDate() + "/" + mes + "/" + hoje.getFullYear())
            var hora = (hoje.getHours() + ":" + hoje.getMinutes()) 
            data_excluida.innerHTML = `${data}  ${hora}`
            

            var linha_excluida = document.createElement("tr")
            linha_excluida.appendChild(texto_excluido)
            linha_excluida.appendChild(data_excluida)

            var tabela_exc = document.getElementById("tabela_exc")
            tabela_exc.appendChild(linha_excluida)

        }

            


        


        function concluido(id_check, id_li_check, valor_lista_check ){
            var checkbox = document.getElementById(id_check)
            var li_check = document.getElementById(id_li_check)
            var classe = li_check.className


            if (checkbox.checked){
                
                document.getElementById(id_li_check).style.backgroundColor = "lightgreen"
                var texto_tarefa_check = tarefas[valor_lista_check]
                

                var texto_concluido = texto_tarefa_check[0]
                
                var tarefa_concluida = document.createElement("td")
                tarefa_concluida.innerHTML = texto_concluido


                var data_concluida = document.createElement("td")
                var hoje = new Date()
                var mes = parseInt(hoje.getMonth())
                mes++
                var data =  (hoje.getDate() + "/" + mes + "/" + hoje.getFullYear())
                var hora = (hoje.getHours() + ":" + hoje.getMinutes()) 
                data_concluida.innerHTML = `${data}  ${hora}`

                pegarID_con = id_li_check.split("_")

                id_tabela_con = pegarID_con[1]
                

                var linha_concluido = document.createElement("tr")
                linha_concluido.setAttribute("id", `tabela_${id_tabela_con}` )
                linha_concluido.appendChild(tarefa_concluida)
                linha_concluido.appendChild(data_concluida)

                var tabela_c = document.getElementById("tabela_con")
                tabela_c.appendChild(linha_concluido)

                

            }

            else{
                
                if(classe == "li_importante"){
                    document.getElementById(id_li_check).style.backgroundColor = "red"
                }
                else{
                    document.getElementById(id_li_check).style.backgroundColor = "lightgray"
                }
                pegarID_con_else = id_li_check.split("_")

                id_tabela_con_else = pegarID_con_else[1]

                var filho_con = document.getElementById(`tabela_${id_tabela_con_else}`)

                var pai_con = document.getElementById("tabela_con")
                pai_con.removeChild(filho_con)

               
                
            }
            return(id_check)
        }

        function inserir_tarefa(){

            //receber dados aqui
            var textotarefa = document.getElementById("tarefa").value
            var textodata = document.getElementById("data").value
            var data_brasileira = textodata.split('-').reverse().join('-');

            var importante = document.getElementById("importante")

            var select = document.getElementById("select").value
            
           
            
            

            if (textotarefa.length == 0 || textodata.length == 0 ){
                alert("Dados inválidos!")
            }

            else{

            
                //criar texto e lista com as informações (data e texto)
                var texto_data_tarefa = document.createElement("p")
                texto_data_tarefa.setAttribute("class", "descricao_tarefa")
                texto_data_tarefa.innerHTML = `${textotarefa} // ${data_brasileira}`
                

                lista_interna = [textotarefa, data_brasileira]
                tarefas.push(lista_interna)


                //criar checkbox
                var check = document.createElement("input")
                check.setAttribute("id", `check/${tarefas.length}`)
                check.setAttribute("type", "checkbox")
                check.setAttribute("class", "checkbox")
                check.onclick = (function(){


                    var id_check = this.id 
                
                    novo_id_check = id_check.split("/")
                
                    valor_check = novo_id_check[1]

                
                    valor_lista_check = valor_check - 1

                    var id_li_check = `li_${valor_check}`
               

                
                concluido(id_check, id_li_check, valor_lista_check)
                
                return(id_check)
                })



                //criar botao de excluir (função imbutida nele)
                var botao = document.createElement("button")
                botao.setAttribute("id", `bot/${tarefas.length}`)
                botao.setAttribute("class", "botao_excluir")
                botao.innerHTML = "Excluir"
                botao.onclick =  (function() {

                    var id = this.id

                    //separa o numero das letras (bot_'num')
                    id = id.split("/")


                    //pega o valor que estava no id
                    valor = id[1] 

                    //pega o valor e tira 1 pra achar na lista
                    valor_lista = valor - (valor)

                    //cria um id igual ao do 'li' em que está
                    var id_li = `li_${valor}`

                    excluir_tarefas(valor_lista, id_li)

                })

                

            
            

                //criar 'li' com as partes da tarefa (data, titulo, descrição)
                var litarefas = document.createElement("li")
                if(importante.checked){
                    

                    litarefas.setAttribute("id", `li_${tarefas.length}`)
                    litarefas.setAttribute("class", "li_importante" )
                    litarefas.appendChild(check)
                    litarefas.appendChild(texto_data_tarefa)
                    litarefas.appendChild(botao)
                }

                else{
                    
                    litarefas.setAttribute("id", `li_${tarefas.length}`)
                    litarefas.setAttribute("class", "li_normal" )
                    litarefas.appendChild(check)
                    litarefas.appendChild(texto_data_tarefa)
                    litarefas.appendChild(botao)
                }


                //adicionar 'li' na 'ul '

                var lista_tarefas = ""

                if (select == "trabalho"){
                    lista_tarefas = document.getElementById("tarefas_trabalho")
                    lista_tarefas.appendChild(litarefas)
                }

                
                else if (select == "escola"){
                    lista_tarefas = document.getElementById("tarefas_escola")
                    lista_tarefas.appendChild(litarefas)
                }

                
                else if (select == "casa"){
                    lista_tarefas = document.getElementById("tarefas_casa")
                    lista_tarefas.appendChild(litarefas)
                }

                else{
                    lista_tarefas = document.getElementById("tarefas_outras")
                    lista_tarefas.appendChild(litarefas)
                }

                
                //limpar inputs de dados
                document.getElementById("tarefa").value = ""
                document.getElementById("data").value = ""
                document.getElementById("importante").checked = false

            }
}